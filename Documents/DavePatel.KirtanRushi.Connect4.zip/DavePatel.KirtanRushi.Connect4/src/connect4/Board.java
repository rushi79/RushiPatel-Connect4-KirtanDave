package connect4;

public class Board {
	private int grid[][];
	private static final int rows = 7;
	private static final int columns = 6;
	private int spacesLeft = 0;

	Board() {
		grid = new int[rows][columns];
		for (int x = 0; x < rows; x++) {
			for (int y = 0; y < columns; y++) {
				grid[x][y] = 0;
				spacesLeft++;
			}
		}
	}
	public int getSpacesLeft() {
        return spacesLeft;
    }

    public int[][] getGrid() {
        return grid;
    }

    public boolean gridEquals(int a, int b, int c) {
        return grid [a][b] == c;
    }

    public void setGrid(int a, int b, int player2) {
        grid[a][b] = player2;
    }

    public int getRows() {//returns the rows
        return rows;
    }

    public int getColumns() {//returns the rows
        return columns;
    }

    public int checkSpaceInCol(int x) {//checks for room in column and returns free spot.
        int column = -1;
        for (int i = 0; i < columns; i++) {
            if (grid[x][i] == 0) {
                column = i;
            }
        }
        return column;
    }
}
